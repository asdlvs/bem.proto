﻿module $itemname$_Module {

    class $itemname$ {

        constructor() {
        }

    }

    define("$itemname$", ()=> {

    });
}