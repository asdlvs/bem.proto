﻿class $itemname$ {
    constructor() {
    }
} 